package com.sensimaster.app.activities

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.sensimaster.app.R
import com.sensimaster.app.adapters.SensitivityAdapter
import com.sensimaster.app.utils.HistoryRepository

class HistoryActivity : AppCompatActivity() {
    private lateinit var repo: HistoryRepository
    private lateinit var adapter: SensitivityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        repo = HistoryRepository(this)

        val rv = findViewById<RecyclerView>(R.id.rvHistory)
        val empty = findViewById<View>(R.id.emptyState)
        val list = repo.getAll()

        adapter = SensitivityAdapter(list) { s ->
            repo.remove(s.id)
            adapter.removeItem(s)
            if (adapter.itemCount == 0) { rv.visibility = View.GONE; empty.visibility = View.VISIBLE }
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        if (list.isEmpty()) { rv.visibility = View.GONE; empty.visibility = View.VISIBLE }

        findViewById<MaterialButton>(R.id.btnClearAll).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Limpar histórico")
                .setMessage("Apagar todas as sensibilidades salvas?")
                .setPositiveButton("Sim") { _, _ ->
                    repo.clear()
                    adapter.clear()
                    rv.visibility = View.GONE; empty.visibility = View.VISIBLE
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }
}
