package com.sensimaster.app.activities

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.sensimaster.app.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)

        val swVibration = findViewById<SwitchMaterial>(R.id.swVibration)
        val swAuto = findViewById<SwitchMaterial>(R.id.swAutoStart)
        val swHaptic = findViewById<SwitchMaterial>(R.id.swHaptic)

        swVibration.isChecked = prefs.getBoolean("vibration", true)
        swAuto.isChecked = prefs.getBoolean("autostart", false)
        swHaptic.isChecked = prefs.getBoolean("haptic", true)

        swVibration.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("vibration", c).apply() }
        swAuto.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("autostart", c).apply() }
        swHaptic.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("haptic", c).apply() }

        findViewById<TextView>(R.id.tvVersion).text = "Versão 1.0.0 • SensiMaster"
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }
}
