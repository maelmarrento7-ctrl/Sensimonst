package com.sensimaster.app.models

import java.io.Serializable

data class Sensitivity(
    val id: Long = System.currentTimeMillis(),
    val gameType: String,        // "FREE_FIRE" ou "FPS_GENERIC"
    val deviceModel: String,
    val androidVersion: String,
    val ram: String,
    val dpi: Int,
    val fps: Int,
    val graphics: String,        // "Smooth", "Balanced", "HD", "Ultra"

    // Sensibilidades (0-200)
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniperScope: Int,
    val freeLook: Int,

    // Configs adicionais
    val aimPrecision: Int,
    val gyroscope: Int,
    val recoilControl: Int,

    val createdAt: Long = System.currentTimeMillis(),
    var label: String = "Sensi #${(System.currentTimeMillis() / 1000) % 10000}"
) : Serializable {

    fun toShareText(): String = buildString {
        appendLine("🎯 $label")
        appendLine("📱 $deviceModel | $ram | DPI $dpi | $fps FPS")
        appendLine("🎮 ${if (gameType == "FREE_FIRE") "Free Fire" else "FPS Genérico"}")
        appendLine("─────────────────")
        appendLine("• Geral: $general")
        appendLine("• Mira Vermelha: $redDot")
        appendLine("• Mira 2x: $scope2x")
        appendLine("• Mira 4x: $scope4x")
        appendLine("• Sniper: $sniperScope")
        appendLine("• Olhar Livre: $freeLook")
        appendLine("─────────────────")
        appendLine("• Precisão: $aimPrecision")
        appendLine("• Giroscópio: $gyroscope")
        appendLine("• Controle Recuo: $recoilControl")
        appendLine("─────────────────")
        appendLine("⚡ Gerado por SensiMaster")
    }
}
