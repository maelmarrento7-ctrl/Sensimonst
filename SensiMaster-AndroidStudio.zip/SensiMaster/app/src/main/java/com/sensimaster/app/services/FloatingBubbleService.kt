package com.sensimaster.app.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.core.app.NotificationCompat
import com.sensimaster.app.R
import com.sensimaster.app.models.Sensitivity
import com.sensimaster.app.utils.DeviceDetector
import com.sensimaster.app.utils.HistoryRepository
import com.sensimaster.app.utils.SensitivityGenerator
import kotlin.math.abs

class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var isPanelOpen = false
    private lateinit var history: HistoryRepository

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        history = HistoryRepository(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startInForeground()
        showBubble()
    }

    private fun startInForeground() {
        val channelId = "sensi_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Painel Flutuante",
                NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_target)
            .setContentTitle("SensiMaster ativo")
            .setContentText("Toque na bolha para abrir o painel")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1001, notif)
        }
    }

    private fun overlayType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else
        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bubbleView = inflater.inflate(R.layout.view_floating_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 250
        }

        val bubble = bubbleView!!.findViewById<ImageView>(R.id.bubbleIcon)
        bubble.setOnTouchListener(BubbleTouchListener(params))
        windowManager.addView(bubbleView, params)
    }

    private inner class BubbleTouchListener(
        private val params: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private var initialX = 0
        private var initialY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(bubbleView, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            return true
        }
    }

    private fun togglePanel() {
        if (isPanelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        panelView = inflater.inflate(R.layout.view_floating_panel, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        bindPanel(panelView!!)
        windowManager.addView(panelView, params)

        panelView!!.alpha = 0f
        panelView!!.scaleX = 0.85f
        panelView!!.scaleY = 0.85f
        panelView!!.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setInterpolator(OvershootInterpolator(1.2f))
            .setDuration(280).start()

        isPanelOpen = true
    }

    private fun closePanel() {
        panelView?.animate()?.alpha(0f)?.scaleX(0.85f)?.scaleY(0.85f)
            ?.setDuration(180)?.withEndAction {
                panelView?.let { runCatching { windowManager.removeView(it) } }
                panelView = null
            }?.start()
        isPanelOpen = false
    }

    private fun bindPanel(root: View) {
        val tvDevice = root.findViewById<TextView>(R.id.tvDevice)
        val tvSpec = root.findViewById<TextView>(R.id.tvSpec)
        val tvLabel = root.findViewById<TextView>(R.id.tvSensiLabel)
        val tvGeneral = root.findViewById<TextView>(R.id.tvGeneral)
        val tvRedDot = root.findViewById<TextView>(R.id.tvRedDot)
        val tv2x = root.findViewById<TextView>(R.id.tv2x)
        val tv4x = root.findViewById<TextView>(R.id.tv4x)
        val tvSniper = root.findViewById<TextView>(R.id.tvSniper)
        val tvFreeLook = root.findViewById<TextView>(R.id.tvFreeLook)
        val tvDpi = root.findViewById<TextView>(R.id.tvDpi)
        val tvFps = root.findViewById<TextView>(R.id.tvFps)
        val tvGfx = root.findViewById<TextView>(R.id.tvGfx)

        val profile = DeviceDetector.detect(this)
        tvDevice.text = "${profile.manufacturer} ${profile.model}"
        tvSpec.text = "${profile.ramFormatted} • Android ${profile.androidVersion} • ${profile.refreshRate}Hz • ${profile.tierLabel}"

        var current: Sensitivity = SensitivityGenerator.generate(
            profile, SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.BALANCED
        )

        fun render(s: Sensitivity) {
            current = s
            tvLabel.text = s.label
            tvGeneral.text = s.general.toString()
            tvRedDot.text = s.redDot.toString()
            tv2x.text = s.scope2x.toString()
            tv4x.text = s.scope4x.toString()
            tvSniper.text = s.sniperScope.toString()
            tvFreeLook.text = s.freeLook.toString()
            tvDpi.text = s.dpi.toString()
            tvFps.text = "${s.fps}fps"
            tvGfx.text = s.graphics
        }
        render(current)

        // Botões de modo
        root.findViewById<View>(R.id.btnPrecision).setOnClickListener {
            render(SensitivityGenerator.generate(profile,
                SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.PRECISION))
        }
        root.findViewById<View>(R.id.btnBalanced).setOnClickListener {
            render(SensitivityGenerator.generate(profile,
                SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.BALANCED))
        }
        root.findViewById<View>(R.id.btnAggressive).setOnClickListener {
            render(SensitivityGenerator.generate(profile,
                SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.AGGRESSIVE))
        }
        root.findViewById<View>(R.id.btnHeadshot).setOnClickListener {
            render(SensitivityGenerator.generate(profile,
                SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.HEADSHOT))
        }

        // Botões de ação
        root.findViewById<View>(R.id.btnRegenerate).setOnClickListener {
            render(SensitivityGenerator.generate(profile,
                SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.BALANCED))
            Toast.makeText(this, "🎲 Nova sensibilidade gerada!", Toast.LENGTH_SHORT).show()
        }
        root.findViewById<View>(R.id.btnSave).setOnClickListener {
            history.add(current)
            Toast.makeText(this, "💾 Salva no histórico!", Toast.LENGTH_SHORT).show()
        }
        root.findViewById<View>(R.id.btnShare).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, current.toShareText())
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(Intent.createChooser(send, "Compartilhar sensibilidade")
                .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        }
        root.findViewById<View>(R.id.btnClose).setOnClickListener { closePanel() }
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
    }
}
