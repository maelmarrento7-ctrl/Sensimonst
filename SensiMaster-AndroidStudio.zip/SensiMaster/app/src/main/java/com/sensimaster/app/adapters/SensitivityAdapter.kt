package com.sensimaster.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sensimaster.app.R
import com.sensimaster.app.models.Sensitivity

class SensitivityAdapter(
    private val items: MutableList<Sensitivity>,
    private val onDelete: (Sensitivity) -> Unit
) : RecyclerView.Adapter<SensitivityAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvLabel: TextView = v.findViewById(R.id.tvItemLabel)
        val tvDevice: TextView = v.findViewById(R.id.tvItemDevice)
        val tvValues: TextView = v.findViewById(R.id.tvItemValues)
        val btnDelete: ImageButton = v.findViewById(R.id.btnItemDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_sensitivity, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val s = items[pos]
        h.tvLabel.text = s.label
        h.tvDevice.text = "${s.deviceModel} • DPI ${s.dpi} • ${s.fps}fps"
        h.tvValues.text = "Geral ${s.general}  •  Red ${s.redDot}  •  2x ${s.scope2x}  •  4x ${s.scope4x}  •  Sniper ${s.sniperScope}"
        h.btnDelete.setOnClickListener { onDelete(s) }
    }

    fun removeItem(s: Sensitivity) {
        val idx = items.indexOfFirst { it.id == s.id }
        if (idx >= 0) { items.removeAt(idx); notifyItemRemoved(idx) }
    }

    fun clear() { val n = items.size; items.clear(); notifyItemRangeRemoved(0, n) }
}
