package com.sensimaster.app.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import com.sensimaster.app.models.DeviceProfile

object DeviceDetector {

    fun detect(context: Context): DeviceProfile {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val ramGb = memInfo.totalMem.toFloat() / (1024f * 1024f * 1024f)

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val refreshRate = wm.defaultDisplay.refreshRate.toInt()

        return DeviceProfile(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            totalRamGb = ramGb,
            screenDpi = metrics.densityDpi,
            screenWidth = metrics.widthPixels,
            screenHeight = metrics.heightPixels,
            refreshRate = refreshRate,
            processorTier = classifyProcessor(ramGb, Build.VERSION.SDK_INT, refreshRate)
        )
    }

    private fun classifyProcessor(ramGb: Float, sdk: Int, refresh: Int): DeviceProfile.ProcessorTier {
        val score = (ramGb * 10).toInt() + sdk + (refresh / 10)
        return when {
            score < 65 -> DeviceProfile.ProcessorTier.LOW
            score < 90 -> DeviceProfile.ProcessorTier.MID
            score < 115 -> DeviceProfile.ProcessorTier.HIGH
            else -> DeviceProfile.ProcessorTier.FLAGSHIP
        }
    }
}
