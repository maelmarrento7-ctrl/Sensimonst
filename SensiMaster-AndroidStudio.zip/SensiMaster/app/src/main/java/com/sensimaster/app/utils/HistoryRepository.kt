package com.sensimaster.app.utils

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.sensimaster.app.models.Sensitivity

class HistoryRepository(context: Context) {
    private val prefs = context.getSharedPreferences("sensi_history", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val type = object : TypeToken<MutableList<Sensitivity>>() {}.type

    fun getAll(): MutableList<Sensitivity> {
        val raw = prefs.getString(KEY, null) ?: return mutableListOf()
        return runCatching { gson.fromJson<MutableList<Sensitivity>>(raw, type) }.getOrNull() ?: mutableListOf()
    }

    fun add(s: Sensitivity) {
        val list = getAll()
        list.add(0, s)
        if (list.size > 50) list.removeAt(list.lastIndex)
        save(list)
    }

    fun remove(id: Long) {
        val list = getAll().filterNot { it.id == id }.toMutableList()
        save(list)
    }

    fun clear() = prefs.edit().remove(KEY).apply()

    private fun save(list: List<Sensitivity>) {
        prefs.edit().putString(KEY, gson.toJson(list)).apply()
    }

    companion object { private const val KEY = "history_json" }
}
