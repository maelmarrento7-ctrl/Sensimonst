package com.sensimaster.app.utils

import com.sensimaster.app.models.DeviceProfile
import com.sensimaster.app.models.Sensitivity
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Gerador inteligente de sensibilidade baseado no perfil do dispositivo.
 * Aplica heurísticas + randomização para criar configs únicas e equilibradas.
 */
object SensitivityGenerator {

    const val GAME_FREE_FIRE = "FREE_FIRE"
    const val GAME_FPS_GENERIC = "FPS_GENERIC"

    fun generate(profile: DeviceProfile, gameType: String, mode: Mode = Mode.BALANCED): Sensitivity {
        val tierBoost = when (profile.processorTier) {
            DeviceProfile.ProcessorTier.LOW -> -15
            DeviceProfile.ProcessorTier.MID -> 0
            DeviceProfile.ProcessorTier.HIGH -> 8
            DeviceProfile.ProcessorTier.FLAGSHIP -> 15
        }

        val refreshBoost = when {
            profile.refreshRate >= 120 -> 10
            profile.refreshRate >= 90 -> 5
            else -> 0
        }

        val dpiBoost = when {
            profile.screenDpi > 480 -> 6
            profile.screenDpi > 320 -> 3
            else -> -3
        }

        val baseGeneral = when (mode) {
            Mode.PRECISION -> 75
            Mode.BALANCED -> 95
            Mode.AGGRESSIVE -> 130
            Mode.HEADSHOT -> 145
        }

        val adjust = tierBoost + refreshBoost + dpiBoost
        val rand = { range: Int -> Random.nextInt(-range, range + 1) }

        val general = clamp(baseGeneral + adjust + rand(8))
        val redDot = clamp(general + 5 + rand(6))
        val scope2x = clamp(general - 8 + rand(6))
        val scope4x = clamp(general - 18 + rand(6))
        val sniper = clamp(general - 32 + rand(8))
        val freeLook = clamp(general + 12 + rand(8))

        val aimPrecision = clamp(80 + tierBoost + rand(10))
        val gyroscope = clamp(when (mode) {
            Mode.PRECISION -> 110
            Mode.BALANCED -> 130
            Mode.AGGRESSIVE -> 160
            Mode.HEADSHOT -> 175
        } + rand(8))
        val recoilControl = clamp(85 + tierBoost + rand(10))

        val (fps, graphics) = recommendedGraphics(profile)
        val targetDpi = recommendedDpi(profile)

        return Sensitivity(
            gameType = gameType,
            deviceModel = "${profile.manufacturer} ${profile.model}",
            androidVersion = "Android ${profile.androidVersion}",
            ram = profile.ramFormatted,
            dpi = targetDpi,
            fps = fps,
            graphics = graphics,
            general = general,
            redDot = redDot,
            scope2x = scope2x,
            scope4x = scope4x,
            sniperScope = sniper,
            freeLook = freeLook,
            aimPrecision = aimPrecision,
            gyroscope = gyroscope,
            recoilControl = recoilControl,
            label = "${mode.label} • ${profile.tierLabel}"
        )
    }

    private fun recommendedGraphics(profile: DeviceProfile): Pair<Int, String> = when (profile.processorTier) {
        DeviceProfile.ProcessorTier.LOW -> 30 to "Smooth"
        DeviceProfile.ProcessorTier.MID -> 60 to "Balanced"
        DeviceProfile.ProcessorTier.HIGH -> min(profile.refreshRate, 90) to "HD"
        DeviceProfile.ProcessorTier.FLAGSHIP -> min(profile.refreshRate, 120) to "Ultra"
    }

    private fun recommendedDpi(profile: DeviceProfile): Int {
        val base = when (profile.processorTier) {
            DeviceProfile.ProcessorTier.LOW -> 480
            DeviceProfile.ProcessorTier.MID -> 600
            DeviceProfile.ProcessorTier.HIGH -> 720
            DeviceProfile.ProcessorTier.FLAGSHIP -> 800
        }
        return base + Random.nextInt(-40, 41)
    }

    private fun clamp(v: Int) = max(1, min(200, v))

    enum class Mode(val label: String) {
        PRECISION("Precisão"),
        BALANCED("Equilibrada"),
        AGGRESSIVE("Agressiva"),
        HEADSHOT("Headshot")
    }
}
