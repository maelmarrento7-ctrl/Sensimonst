package com.sensimaster.app.activities

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.sensimaster.app.R
import com.sensimaster.app.services.FloatingBubbleService
import com.sensimaster.app.utils.DeviceDetector
import com.sensimaster.app.utils.HistoryRepository
import com.sensimaster.app.utils.SensitivityGenerator

class MainActivity : AppCompatActivity() {

    private lateinit var history: HistoryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        history = HistoryRepository(this)

        val profile = DeviceDetector.detect(this)
        findViewById<TextView>(R.id.tvDeviceName).text = "${profile.manufacturer} ${profile.model}"
        findViewById<TextView>(R.id.tvDeviceSpecs).text =
            "RAM: ${profile.ramFormatted}  •  ${profile.resolution}  •  ${profile.refreshRate}Hz  •  ${profile.tierLabel}"
        findViewById<TextView>(R.id.tvAndroidVersion).text = "Android ${profile.androidVersion} (API ${profile.sdkInt})"

        // Card preview de sensibilidade rápida
        val preview = SensitivityGenerator.generate(
            profile, SensitivityGenerator.GAME_FREE_FIRE, SensitivityGenerator.Mode.BALANCED
        )
        findViewById<TextView>(R.id.tvPreviewGeneral).text = preview.general.toString()
        findViewById<TextView>(R.id.tvPreviewRedDot).text = preview.redDot.toString()
        findViewById<TextView>(R.id.tvPreview2x).text = preview.scope2x.toString()
        findViewById<TextView>(R.id.tvPreview4x).text = preview.scope4x.toString()

        findViewById<MaterialButton>(R.id.btnStartBubble).setOnClickListener {
            if (canDrawOverlays()) {
                startService(Intent(this, FloatingBubbleService::class.java))
                Toast.makeText(this, "🚀 Painel flutuante ativado!", Toast.LENGTH_SHORT).show()
                animateLaunch(it)
            } else {
                requestOverlayPermission()
            }
        }

        findViewById<MaterialButton>(R.id.btnStopBubble).setOnClickListener {
            stopService(Intent(this, FloatingBubbleService::class.java))
            Toast.makeText(this, "Painel desativado", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialCardView>(R.id.cardHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardGenerate).setOnClickListener {
            val s = SensitivityGenerator.generate(
                profile, SensitivityGenerator.GAME_FREE_FIRE,
                SensitivityGenerator.Mode.values().random()
            )
            history.add(s)
            Toast.makeText(this, "🎯 ${s.label} gerada e salva!", Toast.LENGTH_LONG).show()
            recreate()
        }
    }

    private fun animateLaunch(v: android.view.View) {
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(120)
            .withEndAction {
                v.animate().scaleX(1f).scaleY(1f)
                    .setInterpolator(OvershootInterpolator(2f)).setDuration(220).start()
            }.start()
    }

    private fun canDrawOverlays(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        Settings.canDrawOverlays(this) else true

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(this, PermissionActivity::class.java))
        }
    }
}
