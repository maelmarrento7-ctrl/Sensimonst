package com.sensimaster.app.models

data class DeviceProfile(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val totalRamGb: Float,
    val screenDpi: Int,
    val screenWidth: Int,
    val screenHeight: Int,
    val refreshRate: Int,
    val processorTier: ProcessorTier
) {
    enum class ProcessorTier { LOW, MID, HIGH, FLAGSHIP }

    val ramFormatted: String
        get() = "${"%.1f".format(totalRamGb)} GB"

    val resolution: String
        get() = "${screenWidth}x${screenHeight}"

    val tierLabel: String
        get() = when (processorTier) {
            ProcessorTier.LOW -> "Básico"
            ProcessorTier.MID -> "Intermediário"
            ProcessorTier.HIGH -> "Avançado"
            ProcessorTier.FLAGSHIP -> "Top de Linha"
        }
}
